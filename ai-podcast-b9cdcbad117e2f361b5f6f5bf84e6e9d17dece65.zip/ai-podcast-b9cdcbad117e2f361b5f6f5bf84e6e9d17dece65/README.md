Experimental project to familiarize myself with AI coding and development tools. I hope you enjoy it.

Cheers,

Ariel Poler

@ariel
