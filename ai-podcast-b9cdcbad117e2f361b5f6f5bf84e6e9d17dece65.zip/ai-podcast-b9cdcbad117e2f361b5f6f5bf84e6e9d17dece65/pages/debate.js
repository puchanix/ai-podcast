import DebateInterface from "../components/debate-interface"

export default function DebatePage() {
  return <DebateInterface />
}
